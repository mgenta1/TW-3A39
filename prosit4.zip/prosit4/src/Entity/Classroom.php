<?php

namespace App\Entity;
use App\Repository\ClassroomRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ClassroomRepository::class)]
class Classroom
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 5)]
    private ?string $name = null;

    #[ORM\OneToMany(mappedBy: 'classroom', targetEntity: Student::class, orphanRemoval: true)]
    private Collection $Students;

    public function __construct()
    {
        $this->Students = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(string $name): static
    {
        $this->name = $name;

        return $this;
    }

    /**
     * @return Collection<int, Student>
     */
    public function getStudents(): Collection
    {
        return $this->Students;
    }

    public function addStudent(Student $Student): static
    {
        if (!$this->Students->contains($Student)) {
            $this->Students->add($Student);
            $Student->setClassroom($this);
        }

        return $this;
    }

    public function removeStudent(Student $Student): static
    {
        if ($this->Students->removeElement($Student)) {
            // set the owning side to null (unless already changed)
            if ($Student->getClassroom() === $this) {
                $Student->setClassroom(null);
            }
        }

        return $this;
    }
}
