<?php

namespace App\Controller;

use App\Entity\Classroom;
use App\Form\ClassroomType;
use App\Repository\ClassroomRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request; 
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ClassroomController extends AbstractController
{
    
    #[Route('/classroom', name: 'app_classroom')]
    public function index(ClassroomRepository $classroomRepository,Request $request): Response
    {
        $result=$classroomRepository->findall();
        $classroom =new Classroom;
        $form = $this->createForm(ClassroomType::class, $classroom);

        $form->handleRequest($request);
       
        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($classroom);
            $entityManager->flush();

            return $this->redirectToRoute('app_classroom');
        }
        return $this->render('classroom/index.html.twig', [
            'list' => $result,
            'form' => $form->createView(),
        ]);
    }
    #[Route('/classroom/delete/{id}', name: 'delet_classroom')]

    public function delete($id): Response
    {
        $entityManager = $this->getDoctrine()->getManager();
        $classroom = $entityManager->getRepository(Classroom::class)->findOneBy(['id' => $id]);

        if (!$classroom) {
            throw $this->createNotFoundException('classroom not found');
        }

        $entityManager->remove($classroom);
        $entityManager->flush();

        $this->addFlash('success', 'Le classroom a été supprimé avec succès.');

        return $this->redirectToRoute('app_classroom'); 
    }
    #[Route('/classroom/modif/{id}', name: 'modif_classroom')]
    public function modif($id , Request $request): Response
    {
        $entityManager = $this->getDoctrine()->getManager();
        $classroom = $entityManager->getRepository(Classroom::class)->findOneBy(['id' => $id]);
        $form = $this->createForm(ClassroomType::class, $classroom);

        $form->handleRequest($request);
       
        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($classroom);
            $entityManager->flush();

            return $this->redirectToRoute('app_classroom');
        }
        return $this->render('classroom/upd.html.twig', [
            'form' => $form->createView(),
        ]);
    }
    }