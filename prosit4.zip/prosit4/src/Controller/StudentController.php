<?php

namespace App\Controller;
use App\Entity\Student;
use App\Form\StudentType;
use App\Repository\StudentRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request; 
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class StudentController extends AbstractController
{
    #[Route('/', name: 'home')]
    public function home(): Response
    {
        return $this->render('base.html.twig',);
    }
    #[Route('/Student', name: 'app_Student')]
    public function index(StudentRepository $StudentRepository , Request $request): Response
    {
        $result = $StudentRepository->findAll();
        $Student =new Student;
        $form = $this->createForm(StudentType::class, $Student);

        $form->handleRequest($request);
       
        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($Student);
            $entityManager->flush();

            return $this->redirectToRoute('app_Student');
          
        }
        return $this->render('Student/index.html.twig', [
            'list' => $result,
            'form' => $form->createView(),
        ]);
    }
    #[Route('/Student/delete/{id}', name: 'delet_Student')]

    public function delete($id): Response
    {
        $entityManager = $this->getDoctrine()->getManager();
        $Student = $entityManager->getRepository(Student::class)->findOneBy(['id' => $id]);

        if (!$Student) {
            throw $this->createNotFoundException('Student not found');
        }

        $entityManager->remove($Student);
        $entityManager->flush();

        $this->addFlash('success', 'Le Student a été supprimé avec succès.');

        return $this->redirectToRoute('app_Student'); 
    }
    #[Route('/Student/modif/{id}', name: 'modif_Student')]
    public function modif($id , Request $request): Response
    {
        $entityManager = $this->getDoctrine()->getManager();
        $Student = $entityManager->getRepository(Student::class)->findOneBy(['id' => $id]);
        $form = $this->createForm(StudentType::class, $Student);

        $form->handleRequest($request);
       
        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($Student);
            $entityManager->flush();

            return $this->redirectToRoute('app_Student');
        }
        return $this->render('Student/upd.html.twig', [
            'form' => $form->createView(),
        ]);
    }
}