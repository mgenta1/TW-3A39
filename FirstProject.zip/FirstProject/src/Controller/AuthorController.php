<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class AuthorController extends AbstractController
{   public  $users = array(
    array('id' => 1, 'picture' => '/images/Victor-Hugo.jpg','username' => 'Victor Hugo', 'email' =>
    'victor.hugo@gmail.com ', 'nb_books' => 100),
    array('id' => 2, 'picture' => '/images/william-shakespeare.jpg','username' => ' William Shakespeare', 'email' =>
    ' william.shakespeare@gmail.com', 'nb_books' => 200 ),
    array('id' => 3, 'picture' => '/images/Taha_Hussein.jpg','username' => 'Taha Hussein', 'email' =>
    'taha.hussein@gmail.com', 'nb_books' => 300),
    );
    
    #[Route('/author/{nom}', name: 'Author')]
    public function showAuthor($nom): Response
    {
       
        if (!isset($this->users) || empty($this->users)) 
        {
            return $this->render('service/error.html.twig');
        }
        else
        {
    return $this->render('service/showAuthor.html.twig', [
        'name' => $nom,
        'users' => $this->users,
    ]);
    }
}


#[Route('/authorr/{nom}', name: 'Authorr')]
public function showAuthorr($nom): Response
{
   
   
return $this->render('service/show.html.twig', [
    'user' => $this->users[$nom-1],
]);
}
}



/*#[Route('/author/{id}', name: 'detail')]

public function authorDetails($id): Response
{
    $users = array(
        array('id' => 1, 'picture' => '/images/Victor-Hugo.jpg','username' => 'Victor Hugo', 'email' =>
        'victor.hugo@gmail.com ', 'nb_books' => 100),
        array('id' => 2, 'picture' => '/images/william-shakespeare.jpg','username' => ' William Shakespeare', 'email' =>
        ' william.shakespeare@gmail.com', 'nb_books' => 200 ),
        array('id' => 3, 'picture' => '/images/Taha_Hussein.jpg','username' => 'Taha Hussein', 'email' =>
        'taha.hussein@gmail.com', 'nb_books' => 300),
        );
    $user = $users[$id];

    return $this->render('service/authorDetails.html.twig', [
        'id' => $id,

    ]);
}*/